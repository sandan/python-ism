#!/usr/bin/env python3
# mycopy.py - copy files
import sys, os
from os import O_RDONLY, O_RDWR, O_CREAT, O_TRUNC
from mmap import mmap, MAP_PRIVATE, MAP_SHARED, PROT_READ, PROT_WRITE

if (len(sys.argv) != 3):
    raise SystemExit("Usage: %s file1 file2" %sys.argv[0])

flen = os.path.getsize(sys.argv[1])     # get file length

fd1 = os.open(sys.argv[1], O_RDONLY)
fd2 = os.open(sys.argv[2], O_RDWR | O_CREAT | O_TRUNC, 0o644)
os.ftruncate(fd2, flen)                 # set file length

buf1 = mmap(fd1, flen, MAP_PRIVATE, PROT_READ)
buf2 = mmap(fd2, flen, MAP_SHARED, PROT_WRITE)

buf2[:] = buf1[:]                       # copy all data

buf1.close(); buf2.close()              # unmap memory
os.close(fd1); os.close(fd2)            # close files

###############################################
#
#    $ mycopy.py
#    Usage: ./mycopy.py file1 file2
#
#    $ mycopy.py file1 file2
#     
