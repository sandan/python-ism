#!/usr/bin/env python
# myserver.py - TCP server, binary data
import os, sys
from socket import socket, AF_INET, SOCK_STREAM
from struct import Struct
from logging import basicConfig, log, ERROR, DEBUG
basicConfig(level=DEBUG, format="Server: %(message)s",)

HOST = "localhost"
PORT = 2500
MAXDATA = 256
packer = Struct("I")         # file length 
conn = file  = None          # connection, file handle

sock = socket(AF_INET, SOCK_STREAM)
address = (HOST, PORT)
sock.bind(address)
sock.listen(5)

log(DEBUG, "%s %d running..." %address)
try:
    while True:
        (conn, addr) = sock.accept()
        filename = conn.recv(MAXDATA)
        log(DEBUG, "received filename %s:" %filename)
        filelength = os.path.getsize(filename)
        log(DEBUG, "sending file length %d:" %filelength)
        packdata = packer.pack(filelength)
        conn.sendall(packdata)
        file = open(filename)
        data = file.read()
        log(DEBUG, "sending %d bytes" %len(data))
        conn.sendall(data)
except KeyboardInterrupt:
    log(DEBUG, "stopped")
    sys.exit(1)
finally:
    if conn is not None:
        conn.close()
    if file is not None:
        file.close()

#####################################
#
#     $ myserver.py
#     Server: localhost 2500 running...
#
#     ^C
#     Server: stopped
#
