#!venv/bin/python
# run.py - starts up development web server
from app import app
app.run(debug=True)
